<?php
require __DIR__ .'/../settings/app.php';
	
$app->run();

?>